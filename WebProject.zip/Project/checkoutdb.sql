-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 25, 2024 at 11:10 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `checkoutdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `checkoutdb`
--

CREATE TABLE `checkoutdb` (
  `firstName` text NOT NULL,
  `lastName` text NOT NULL,
  `Email` text NOT NULL,
  `Address` text NOT NULL,
  `Address2` text DEFAULT NULL,
  `City` text NOT NULL,
  `zipCode` int(11) NOT NULL,
  `paymentMethod` text NOT NULL,
  `creditCard` int(11) DEFAULT NULL,
  `CreditHolder` text DEFAULT NULL,
  `dTime` text NOT NULL,
  `Notes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `checkoutdb`
--

INSERT INTO `checkoutdb` (`firstName`, `lastName`, `Email`, `Address`, `Address2`, `City`, `zipCode`, `paymentMethod`, `creditCard`, `CreditHolder`, `dTime`, `Notes`) VALUES
('Omar', 'Tardi', 'awfeadw@fs.com', 'Amman', 'sfefg', 'Amman', 23912, 'Credit', 0, '', '1', '232'),
('sffs', 'fsfs', 'awfeadw@fs.com', 'sfgsf', 'fsfsf', 'Amman', 12112, 'Cash', 0, '', '1', 'sfesfsefes'),
('da', 'da', 'awfeadw@fs.com', 'da', 'da', 'Amman', 22222, 'Cash', 0, '', '1', 'da'),
('da', 'da', 'awfeadw@fs.com', 'da', 'da', 'Amman', 11111, 'Cash', 0, '', '1', ''),
('omar', 'tardi', 'awfeadw@fs.com', 'dadad', 'dadad', 'Amman', 23232, 'Credit', 2147483647, 'daddecvsd', '2', ''),
('dfasd', 'fsf', 'awfeadw@fs.com', 'fsfs', 'sff', 'Amman', 23234, 'Cash', 0, '', '1', ''),
('Omar', 'Tardi', 'awfeadw@fs.com', 'dwd', '123', 'Amman', 32323, 'Cash', 0, '', '1', ''),
('wfw', 'fw', 'awfeadw@fs.com', 'fw', 'fw', 'Amman', 23232, 'Credit', 2147483647, 'dasfds', '1', ''),
('da', 'a', 'ds@gmail.com', 'dad', 'dada', 'Amman', 34343, 'Cash', 0, '', '1', ''),
('Omar', 'Tardi', 'ds@gmail.com', 'fs', 'fs', 'Amman', 23232, 'Cash', 0, '', '1', ''),
('Omar', 'Tardi', 'ds@gmail.com', 'dadas', 'fsf', 'Amman', 34343, 'Cash', 0, '', '1', ''),
('fsfs', 'fsfs', 'ds@gmail.com', 'Amman', 'fsfsf', 'Amman', 23232, 'Cash', 0, '', '1', 'fs'),
('Omar', 'Tardi', 'ds@gmail.com', 'fsf', 'fsfs', 'Amman', 34343, 'Cash', 0, '', '1', ''),
('Omar', 'Tardi', 'ds@gmail.com', 'da', 'da', 'Amman', 23232, 'Cash', 0, '', '1', ''),
('fs', 'fs', 'ds@gmail.com', 'fs', 'fs', 'Amman', 32323, 'Cash', 0, '', '1', ''),
('fsfs', 'fsf', 'ds@gmail.com', 'da', 'fs', 'Amman', 34343, 'Cash', 0, '', '1', '43'),
('fwsfes', 'wsfse', 'ds@gmail.com', 'fse', 'fs', 'Amman', 23232, 'Cash', 0, '', '1', ''),
('fsfsf', 'fsfs', 'ds@gmail.com', 'sfsfs', 'fsfsf', 'Amman', 23232, 'Cash', 0, '', '1', ''),
('fsf', 'fsfs', 'ds@gmail.com', 'fsfs', 'fsef', 'Amman', 32323, 'Cash', 0, '', '1', ''),
('da', 'da', 'ds@gmail.com', 'das', 'ds', 'Amman', 23234, 'Cash', 0, '', '1', ''),
('d', 'ds', 'ds@gmail.com', 'gdgd', 'dgdgd', 'Amman', 32323, 'Cash', 0, '', '1', ''),
('Omar', 'Tardi', 'ds@gmail.com', 'fs', 'fs', 'Amman', 24242, 'Cash', 0, '', '1', ''),
('Omar', 'gege', 'ds@gmail.com', 'gdgdg', 'dgdr', 'Amman', 43543, 'Cash', 0, '', '1', ''),
('fs', 'fs', 'ds@gmail.com', 'fs', 'ffsf', 'Amman', 43453, 'Cash', 0, '', '1', 'sff'),
('fs', 'fs', 'ds@gmail.com', 'fs', 'fs', 'Amman', 32323, 'Cash', 0, '', '1', ''),
('da', 'da', 'ds@gmail.com', 'dad', 'dad', 'Amman', 34543, 'Cash', 0, '', '1', 'fs'),
('gsg', 'gs', 'ds@gmail.com', 'fsfs', 'fsf', 'Amman', 34343, 'Cash', 0, '', '1', 'fsf'),
('fs', 'fs', 'ds@gmail.com', 'fs', 'fs', 'Amman', 43434, 'Cash', 0, '', '1', 'sfsf'),
('fsfs', 'fsfs', 'ds@gmail.com', 'fsfs', 'fsfws', 'Amman', 53535, 'Cash', 0, '', '1', ''),
('sfsf', 'fsf', 'ds@gmail.com', 'fsfs', 'fsfs', 'Amman', 45353, 'Cash', 0, '', '1', ''),
('fgs', 'ffs', 'ds@gmail.com', 'sffs', '3r', 'Amman', 43242, 'Cash', 0, '', '1', ''),
('FSF', 'FSFS', 'ds@gmail.com', 'FSF', 'FS', 'Amman', 43434, 'Cash', 0, '', '1', ''),
('vsv', 'vsvs', 'ds@gmail.com', 'vsv', 'rersvs', 'Amman', 35353, 'Cash', 0, '', '1', 'fsfgsges');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
