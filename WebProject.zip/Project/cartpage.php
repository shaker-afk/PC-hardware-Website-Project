<?php
session_start();
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "products_descriptionDB";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

function fetchDataFromDatabase($conn) {
    $sql = "SELECT * FROM orderedproducts";
    $result = $conn->query($sql);

    $products = array();
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $products[] = $row;
        }
    }

    return $products;
}
function fetchtotalFromDatabase($conn) {
    $sql = "SELECT * FROM orderedproducts";
    $result = $conn->query($sql);

    $products = array();
    $total = 0;
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $currentProduct = $row; 
            $products[] = $currentProduct;
            $productPrice = $currentProduct['productPrice'];
            $productCount = $currentProduct['quantity'];
            $total = $total + ($productPrice * $productCount);             
        }
    }
    $totalprice = $total;
    return $total;
}

$totalprice =fetchtotalFromDatabase($conn);
$products = fetchDataFromDatabase($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SHOPPING BAG</title>
    <link rel="stylesheet" href="cartPage.css">
    <link href="Products.css" rel="stylesheet">
    
</head>
<body>
       <!--Website Header-->
 <header>
    <!--Email-->
<a id="Top"></a>
<div class="FlexBoxTest">
    <div id="EmailPart">
        <div id="EmailLogo"> 
            <a href="mailto:Company@gmail.com">
            <svg class="HeaderLogos"  xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--!Font Awesome Free 6.5.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path fill="#f5f5f5" d="M48 64C21.5 64 0 85.5 0 112c0 15.1 7.1 29.3 19.2 38.4L236.8 313.6c11.4 8.5 27 8.5 38.4 0L492.8 150.4c12.1-9.1 19.2-23.3 19.2-38.4c0-26.5-21.5-48-48-48H48zM0 176V384c0 35.3 28.7 64 64 64H448c35.3 0 64-28.7 64-64V176L294.4 339.2c-22.8 17.1-54 17.1-76.8 0L0 176z"/></svg>
        
        </div>
    
        <div id="EmailP1">
            <p >info@company.com</p>
        </div>
    </a>
    </div>
    <div id="Promocode">
         <!--Promocode-->
   <p  >USE CODE FULL_MARK_IN_PROJECT FOR 20% OFF!</p>
    </div>
    
   <!--SocialMedia-->
    <div id="Socials">
        <div id="SocialsFlexBox">
        <a href="https://www.instagram.com/psutofficial/">
            <svg class="HeaderLogos" id="InstagramLogo"  xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><!--!Font Awesome Free 6.5.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path fill="#ffffff" d="M224.1 141c-63.6 0-114.9 51.3-114.9 114.9s51.3 114.9 114.9 114.9S339 319.5 339 255.9 287.7 141 224.1 141zm0 189.6c-41.1 0-74.7-33.5-74.7-74.7s33.5-74.7 74.7-74.7 74.7 33.5 74.7 74.7-33.6 74.7-74.7 74.7zm146.4-194.3c0 14.9-12 26.8-26.8 26.8-14.9 0-26.8-12-26.8-26.8s12-26.8 26.8-26.8 26.8 12 26.8 26.8zm76.1 27.2c-1.7-35.9-9.9-67.7-36.2-93.9-26.2-26.2-58-34.4-93.9-36.2-37-2.1-147.9-2.1-184.9 0-35.8 1.7-67.6 9.9-93.9 36.1s-34.4 58-36.2 93.9c-2.1 37-2.1 147.9 0 184.9 1.7 35.9 9.9 67.7 36.2 93.9s58 34.4 93.9 36.2c37 2.1 147.9 2.1 184.9 0 35.9-1.7 67.7-9.9 93.9-36.2 26.2-26.2 34.4-58 36.2-93.9 2.1-37 2.1-147.8 0-184.8zM398.8 388c-7.8 19.6-22.9 34.7-42.6 42.6-29.5 11.7-99.5 9-132.1 9s-102.7 2.6-132.1-9c-19.6-7.8-34.7-22.9-42.6-42.6-11.7-29.5-9-99.5-9-132.1s-2.6-102.7 9-132.1c7.8-19.6 22.9-34.7 42.6-42.6 29.5-11.7 99.5-9 132.1-9s102.7-2.6 132.1 9c19.6 7.8 34.7 22.9 42.6 42.6 11.7 29.5 9 99.5 9 132.1s2.7 102.7-9 132.1z"/></svg>
        </a>
        <a href="https://www.google.com/maps/place/Princess+Sumaya+University+for+Technology/@32.0234755,35.8735991,17z/data=!3m1!4b1!4m6!3m5!1s0x151c9fa16e6250e1:0x36e46cbcb207a3fa!8m2!3d32.023471!4d35.876174!16zL20vMDY5eGI1?entry=ttu">
           <svg class="HeaderLogos" id="LocationLogo"  xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><!--!Font Awesome Free 6.5.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path fill="#ffffff" d="M215.7 499.2C267 435 384 279.4 384 192C384 86 298 0 192 0S0 86 0 192c0 87.4 117 243 168.3 307.2c12.3 15.3 35.1 15.3 47.4 0zM192 128a64 64 0 1 1 0 128 64 64 0 1 1 0-128z"/></svg>
        </a>
        <a href="https://www.facebook.com/PSUTOFFICIAL">
           <svg class="HeaderLogos" id="FacebookLogo" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--!Font Awesome Free 6.5.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path fill="#ffffff" d="M512 256C512 114.6 397.4 0 256 0S0 114.6 0 256C0 376 82.7 476.8 194.2 504.5V334.2H141.4V256h52.8V222.3c0-87.1 39.4-127.5 125-127.5c16.2 0 44.2 3.2 55.7 6.4V172c-6-.6-16.5-1-29.6-1c-42 0-58.2 15.9-58.2 57.2V256h83.6l-14.4 78.2H287V510.1C413.8 494.8 512 386.9 512 256h0z"/></svg>
        </a>
        </div>
    </div>

  
</div>

 
</header>



    <!--NavBarflexBox-->
<div id="Navigation_bar">
    <!--Company Logo-->
    
    <h3 id="CompanyLogo" onclick="IndexCalled()">CSsystems</h3>
  

    <!--CPU-->
 
    <div class="NavBar_CPU" onclick="submitform('CPUs')">
       
    <svg   xmlns="http://www.w3.org/2000/svg" width="55" height="50" viewBox="0 0 24 24" style="fill: rgba(0, 0, 0, 1);transform: ;msFilter:;"><path d="M19 7a2 2 0 0 0-2-2h-1V2h-2v3h-4V2H8v3H7a2 2 0 0 0-2 2v1H2v2h3v4H2v2h3v1a2 2 0 0 0 2 2h1v3h2v-3h4v3h2v-3h1a2 2 0 0 0 2-2v-1h3v-2h-3v-4h3V8h-3V7zm-4 8H9V9h6v6z"></path></svg>

    <h4>CPU</h4>

    </div>
   
    <!--RAM-->
    <div class="NavBar_RAM" onclick="submitform('RAMs')">
      
        <svg xmlns="http://www.w3.org/2000/svg"  width="55" height="50"  shape-rendering="geometricPrecision" text-rendering="geometricPrecision" image-rendering="optimizeQuality" fill-rule="evenodd" clip-rule="evenodd" viewBox="0 0 512 375.4"><path fill-rule="nonzero" d="M25.13 39.95h34.22V0H85.2v39.95h47.65V0h25.84v39.95h47.64V0h25.84v39.95h47.65V0h25.84v39.95h47.65V0h25.84v39.95h47.65V0h25.84v39.95h34.23c6.88 0 13.15 2.82 17.71 7.37l.05.05c4.54 4.55 7.37 10.82 7.37 17.71v247.73c0 6.88-2.83 13.15-7.37 17.71l-.05.05c-4.56 4.54-10.83 7.37-17.71 7.37h-34.23v37.46H426.8v-37.46h-47.65v37.46h-25.84v-37.46h-47.65v37.46h-25.84v-37.46h-47.65v37.46h-25.84v-37.46h-47.64v37.46h-25.84v-37.46H85.2v37.46H59.35v-37.46H25.13c-6.89 0-13.15-2.83-17.71-7.37l-.05-.05C2.83 325.96 0 319.69 0 312.81V65.08c0-6.89 2.83-13.16 7.37-17.71l.05-.05c4.56-4.55 10.82-7.37 17.71-7.37zm154.83 200.1h-35.98l-13.41-30.42h-8.56v30.42H90.83V137.84h51.52c23.44 0 35.16 11.94 35.16 35.81 0 16.36-5.07 27.15-15.21 32.38l17.66 34.02zm-57.95-77.57v23.5h9.05c3.93 0 6.79-.41 8.59-1.23 1.8-.82 2.7-2.7 2.7-5.64v-9.76c0-2.95-.91-4.83-2.7-5.64-1.8-.82-4.67-1.23-8.59-1.23h-9.05zm98.67 77.57h-34.5l26.49-102.21h50.53l26.49 102.21h-34.5l-3.76-16.19h-26.99l-3.76 16.19zm13.29-70.81-3.64 28.62h15.04l-3.48-28.62h-7.92zm96.93 70.81h-34.18l6.21-102.21h42.69l12.76 52h1.14l12.75-52h42.68l6.22 102.21h-34.18l-1.96-49.55h-1.15l-12.43 49.55h-25.01l-12.59-49.55h-.99l-1.96 49.55zM486.16 65.79H25.84V312.1h460.32V65.79z"/></svg>
        <h4>RAM</h4>
    
    </div>

    <!--SSD/HDD-->
    <div class="NavBar_SSD_HDD" onclick="submitform('SSDs&HDDs')">
        
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" style="fill: rgba(0, 0, 0, 1);transform: ;msFilter:;"><path d="m21.983 13.821-1.851-10.18A1.998 1.998 0 0 0 18.165 2H5.835a2 2 0 0 0-1.968 1.643l-1.85 10.178.019.003c-.012.06-.036.114-.036.176v5c0 1.103.897 2 2 2h16c1.103 0 2-.897 2-2v-5c0-.063-.024-.116-.035-.176l.018-.003zM5.835 4h12.331l1.637 9H4.198l1.637-9zM4 19v-4h16l.002 4H4z"></path><path d="M17 16h2v2h-2zm-3 0h2v2h-2z"></path></svg>
        <h4>SSD/HDD</h4>
    
    </div>

    <!--Motherboards-->
    <div class="NavBar_MotherBoards" onclick="submitform('MOTHERBOARDs')">
        
        <img src="motherboard.png">
        <h4>Motherboard</h4>
        
    </div>

        <!--Desktops-->
        <div class="NavBar_Desktop" onclick="submitform('Desktops')">
           
            <img src="DesktopIcon.png" alt="--Desktops--">
            <h4>Desktops</h4>
        
        </div>

        <!--gpu-->
        <div class="NavBar_GPU" onclick="submitform('GPUs')">
            <img src="GPUicon.png" alt="--GPU-">
            <h4>GPU</h4>
        </div>

        <!--Laptop-->
        <div class="NavBar_Laptop"  onclick="submitform('Laptops')">
           
            <img src="LaptopIcon.png" alt="--Laptop--">
            <h4>Laptop</h4>
      
        </div>

        <!--Login-->
        <div class="NavBar_Login"  onclick="return GoToLogin()">
            <img src="Login-Logo.png" alt="--Login--">
        </div>

        <!--Cart-->
        <div class="NavBar_Cart"  onclick="return GoToCart()">
            <img src="shopping-cart.png" alt="--Cart--">
            <h4>Cart</h4> 
        </div>
        
        
    </div>
    
<form method="post" action="Products.php" class="hide">
    <input type="text" class="hide" id="groupclickedinput" name="groupclicked">
    <input type="submit" id="submitselectedgroup" class="hide">
</form>

    <br><br>

    <div id="parent"> 
        <div id="leftBlock">
            <div> <!--<div id="addstrip">
                <div>
                    Check delivery time and services
                </div>
                <button>
                    <div>ENTER PIN CODE</div>
                </button>
            </div>-->
            <!--<div id="offer">
                <div>
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" class="offersV2-base-discountIcon"><g fill="#000" fill-rule="evenodd"><path d="M15.292 10.687v.001c-.198.742.076 1.454.296 2.026l.045.12-.137.021c-.602.094-1.352.211-1.892.75-.538.54-.655 1.288-.748 1.89l-.022.138a22.096 22.096 0 0 1-.12-.045c-.443-.171-.946-.364-1.49-.364-.185 0-.366.023-.536.068-.728.194-1.198.78-1.577 1.249-.032.04-.07.088-.111.137l-.112-.138c-.378-.47-.848-1.054-1.575-1.248a2.092 2.092 0 0 0-.537-.068c-.543 0-1.046.193-1.49.364l-.12.045-.022-.138c-.093-.602-.21-1.35-.749-1.89-.539-.539-1.289-.656-1.891-.75l-.137-.022a15 15 0 0 1 .045-.118c.22-.573.494-1.286.296-2.027-.194-.728-.78-1.199-1.25-1.577L1.323 9l.137-.11c.47-.38 1.055-.85 1.249-1.577.198-.742-.076-1.455-.296-2.028l-.045-.118.137-.022c.602-.094 1.352-.211 1.891-.75.54-.539.656-1.289.75-1.891l.022-.137.119.045c.443.171.947.365 1.49.365.186 0 .367-.024.537-.07.727-.193 1.198-.778 1.576-1.248L9 1.322l.111.137c.379.47.85 1.055 1.576 1.249.17.045.352.069.537.069.544 0 1.047-.194 1.491-.365l.119-.045.022.137c.094.602.21 1.353.75 1.891.538.539 1.288.656 1.89.75l.138.022-.046.119c-.22.572-.494 1.285-.295 2.026.194.728.778 1.199 1.248 1.577.04.033.088.07.137.111l-.137.11c-.47.38-1.054.85-1.249 1.577M18 9c0-.744-1.459-1.286-1.642-1.972-.19-.71.797-1.907.437-2.529-.364-.63-1.898-.372-2.41-.884-.511-.511-.253-2.045-.883-2.41a.647.647 0 0 0-.33-.08c-.585 0-1.403.542-1.998.542a.778.778 0 0 1-.201-.025C10.286 1.46 9.743 0 9 0c-.744 0-1.286 1.459-1.972 1.642a.78.78 0 0 1-.2.025c-.596 0-1.414-.542-2-.542a.647.647 0 0 0-.33.08c-.63.365-.37 1.898-.883 2.41-.512.512-2.046.254-2.41.884-.36.62.627 1.819.437 2.529C1.46 7.714 0 8.256 0 9s1.459 1.286 1.642 1.972c.19.71-.797 1.908-.437 2.53.364.63 1.898.371 2.41.883.511.512.253 2.045.884 2.41.097.056.208.08.33.08.585 0 1.403-.542 1.998-.542a.78.78 0 0 1 .201.025C7.714 16.54 8.256 18 9 18s1.286-1.46 1.973-1.642a.774.774 0 0 1 .2-.025c.595 0 1.413.542 1.998.542a.647.647 0 0 0 .33-.08c.631-.365.373-1.898.884-2.41.512-.512 2.046-.254 2.41-.884.36-.62-.627-1.819-.437-2.529C16.54 10.286 18 9.744 18 9"></path><path d="M10.897 6.34l-4.553 4.562a.536.536 0 0 0 .76.758l4.552-4.562a.536.536 0 0 0-.76-.758M6.75 7.875a1.126 1.126 0 0 0 0-2.25 1.126 1.126 0 0 0 0 2.25M11.25 10.125a1.126 1.126 0 0 0 0 2.25 1.126 1.126 0 0 0 0-2.25"></path></g></svg>
                    <p>Available Offers</p>
                </div>
                <div>
                    <div>
                        
                
                    </div>
                <p>Show More <span id="svg"><svg xmlns="http://www.w3.org/2000/svg" width="7" height="12" viewBox="0 0 7 12" class="offersV2-base-arrowIcon" style="transform: rotate(90deg);"><path fill-rule="evenodd" d="M6.797 5.529a.824.824 0 0 0-.042-.036L1.19.193a.724.724 0 0 0-.986 0 .643.643 0 0 0 0 .94L5.316 6 .203 10.868a.643.643 0 0 0 0 .938.724.724 0 0 0 .986 0l5.566-5.299a.644.644 0 0 0 .041-.978"></path></svg></span></p>
                </div>
            </div>-->
            
            <div id="bulkAction">
            
                <div id="itemselected"> ITEMS SELECTED</div>
                <div>
                    <button  >REMOVE</button>
                    
                </div>
            </div>
        </div>
            <div id="cartitemparent" class="cartitemparent">
            <?php if (!empty($products)) { ?>
               
                <table class="table">
                    <thead>
                        <tr>
                            <th>Product Name</th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($products as $product) { ?>
                            <tr>
                           <?php //echo "<input id=\"malek\" class=\"hide\" type=\"text\" value= $product['productId']>";?>
                                <td><?php echo htmlspecialchars($product['productName']); ?></td>
                                <td><?php echo htmlspecialchars($product['productPrice']); ?></td>
                                <td><?php echo htmlspecialchars($product['quantity']); ?></td>
                                <td><?php echo htmlspecialchars($product['productPrice'] * $product['quantity']); ?></td>
                                <td>  <img onclick="remove($product['productId'])" src="https://cdn.onlinewebfonts.com/svg/img_265949.png" alt="" style="width: 20px;height: 20px;"></td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            <?php } else { ?>
                <p>No products in your shopping bag.</p>
            <?php } ?>

            </div>
        </div>
        <div id="rightBlock">
            <div id="coupons">
                <p>COUPONS</p>
                <div>
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" class="coupons-base-couponIcon"><g fill="none" fill-rule="evenodd" transform="rotate(45 6.086 5.293)"><path stroke="#000" d="M17.5 10V1a1 1 0 0 0-1-1H5.495a1 1 0 0 0-.737.323l-4.136 4.5a1 1 0 0 0 0 1.354l4.136 4.5a1 1 0 0 0 .737.323H16.5a1 1 0 0 0 1-1z"></path><circle cx="5.35" cy="5.35" r="1.35" fill="#000" fill-rule="nonzero"></circle></g></svg>
                    <p>Apply Coupons</p>
                    <button onclick="opencoupon()">APPLY</button>
                </div>
                
            </div>
            <div id="priceContainer">
                <div>PRICE DETAILS (<span id="priceDetails"><?php echo count($products) ?></span> Items)</div>
                <div>total (<span id="priceDetails"><?php echo $totalprice ?></span> JOD)</div>
                <div id="priceBreakup">
                <div>total <span id="priceDetails"></span> (<?php echo $totalprice ?>JOD)</div>
                <div>total <span id="priceDetails"></span> <script> applyCoupon()</script></div>
                <hr>
                <br>
                <div>total Amount <span id="priceDetails"></span> (<?php echo $totalprice ?>JOD)</div>
                
                <input type="button" onclick="GoToPayment()" value="Place Order" style="width: 310px;height: 40px ;color: white;font-size: 25px; background-color:crimson ">
                </div>
            </div>
        </div >
        
        
                <div class="popupdiv" id="couponpopup">
                    <div id="crossselect" onclick="closePopup()" style="cursor: pointer;">
                        <div>APPLY COUPONS</div>
                        <div>
                           <button onclick="closecoupon()"> <img src="https://cdn.onlinewebfonts.com/svg/img_265949.png" alt=""></button>
                        </div>
                    </div>
                    <div id="coupon-form-input">
                        <div id="inputdiv">
                            <input type="text" placeholder="Enter couponcode">
                            <div>CHECK</div>
                        </div>
                    </div>
                    <div id="couponform">
                        <button onclick="applyCoupon()">FULL_MARK_IN_PROJECT</button>
                        <p>Save 30JDs</p>
                        <p>30JDs off on minimum purchase of 200JDs</p>
                        <p>Expires on: 31st December 2024</p>
                    </div>
                    <div>
                        <div id="saving">
                            <div>
                                <p>Maximum savings:</p>
                                <p>30JDs</p>
                            </div>
                            <div>
                                <button id="done" onclick="closecoupon()">
                                    <div>APPLY</div>
                                </button>
                            </div>
                        </div>
                        
                    </div>
                    
                </div>
        </div>
    </div>
    <a href="#Top" id="LinkToTop">
    <div id="bookmark">
        <h4>Back to top</h4>
    </div>
<footer>
<hr>
    
    </a>
    <div id="FooterInfo">
        <h1 id="AboutUS_Text">
            About US
        </h1>
        <p id="AboutUS_Paragraph">
            Welcome to ######, your best destination for all your computer hardware needs.
            Here at ###### we understand that every customer wants top quality hardware at 
            competitive prices.

            At ######, we create a personalized experience with our customers to ensure their needs are
            satisfied. That's why we offer a carefully curated selection of CPU's, RAM, storage devices, motherboards, 
            Desktops, computer GPU's and Laptops.
        </p>
    </div>
    <div id="FooterInfo2">
        <h1>More about us:</h1>
        <p> 32-Wasfi Al-Tal street (Gardenz), Next to Dawacom pharmacy<br>Amman-jordan
        <br><br>
        <img src="cell-phone.png">
        068-312-345 / 069-351-242 / 066-924-901
        <br>
        <img src="whatsapp.png">
        079-213-4628
        <br>
        <img src="mail.png"> companySales@gmail.com
        <br> <br>
       <b><u> Working Hours:</b></u>
       <br>
       Sunday-Thursday: 8 AM - 10 PM <br>
       Friday: 2 PM - 6 PM  <br>
       Saturday: 11 AM - 7 PM  <br>
        </p>
    </div>
</footer>
<div id="Credit">
    <p>Web development by: Omar Tardi (20220598) - Malik Mahmoud (20220659) - Mohammed Amr (20220887) - Mohammad Al Qadi (20220377)
        </p>

</div>

  

<script>

    function submitform(nameofgroup){
        groupclicked = nameofgroup;
        document.getElementById("groupclickedinput").value = groupclicked;
        document.getElementById("submitselectedgroup").click();
    }
    function IndexCalled(){
        window.location.href = "Index.php";

    }
    function GoToProducts(){
        window.location = "Products.php";
        const page = window.open('Products.php');
        page.document.get
    }
    function GoToCart(){
        window.location.href = "cartpage.php";

    }
    function GoToLogin(){
        window.location.href = "Login.php";
    }
    function LoginInmessage(){
        window.location = "Login.php";
        alert("Log in first to proceed");
    }
    function GoToPayment(){
        window.location = "Checkout.php";

    }

</script>

    
</body>
<script src="cartPage.js"></script>
</html>
<?php
// Close connection
$conn->close();
?>