-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 25, 2024 at 11:10 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `products_descriptiondb`
--

-- --------------------------------------------------------

--
-- Table structure for table `orderedproducts`
--

CREATE TABLE `orderedproducts` (
  `userId` int(11) NOT NULL,
  `productId` int(11) NOT NULL,
  `productName` varchar(255) NOT NULL,
  `productPrice` int(11) NOT NULL,
  `productStock` int(11) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orderstable`
--

CREATE TABLE `orderstable` (
  `OrderID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `ProductsList` text NOT NULL,
  `Total` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products_description`
--

CREATE TABLE `products_description` (
  `id` int(11) NOT NULL,
  `groupName` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `stock` int(255) NOT NULL,
  `image` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products_description`
--

INSERT INTO `products_description` (`id`, `groupName`, `name`, `description`, `price`, `stock`, `image`) VALUES
(1, 'Laptops', 'Laptop ASUS Zenbook S 13 ', 'OLED | Intel Core Ultra 7 Processor | 16GB DDR5X | 1TB M.2 | 13.3-inch 3K (2880 x 1800) OLED | Slim & Light Windows 11 Home with Sleeve', 1500, -16, 'Artbossard-49-copy-1200x1200.png'),
(2, 'Laptops', 'ASUS Vivobook Pro 15 ', 'OLED (2024), AI Ready, 15.6” 3K 120Hz OLED Laptop, Intel Core Ultra 7 155H, NVIDIA GeForce RTX 4050, 1TB SSD, Windows 11 Home Cool Silver', 2000, 10, 'ASUS Vivobook Pro 15.png'),
(3, 'Laptops', 'Laptop HP Laptop 15-fd0022ne ', 'Intel Core i7 1355U | 8 GB DDR4 | 512 GB PCIe NVMe | 15.6 inch FHD | Natural silver 13th Generation', 1200, 9, 'Laptop HP Laptop 15-fd0022.png'),
(4, 'Desktops', 'Dell Alienware Aurora R12 ', 'Gaming Desktop-Core i7 11th Generation RTX3060ti 8GB DDR6 - HDD1TB+ 512GB SSD M.2 -RAM 16GB', 1300, 15, 'AUR11-ALNW-CTO2C-1-1200x1200.jpg'),
(5, 'Desktops', 'Dell Optiplex ', 'RTX 3090|Core i3 10th Generation', 900, 10, 'Dell Optiplex 3090-Core i3 10.jpg'),
(6, 'Desktops', 'GTS 4 Gaming Desktop ', 'Core i7 12700 - RTX 3060 12GB / 16 DDR4 / 1 TB SSD - 12th Generation', 1300, 12, 'GTS4Gaming Desktop - Core i7 12700 - RTX 3060.png'),
(7, 'CPUs', 'Intel Core i3-9100F CPU', '9th Generation, Intel Core i3-9100F, 3.60 GHz up to 4.20 GHZ, 6 MB, 4 Cores.', 70, 20, 'Core-i3-9100F-1200x1200.jpg'),
(8, 'CPUs', 'Intel Core i5-9400F CPU', '9th Generation, Intel Core i5-9400F, 2.90 up to 4.10 GHz, 9 MB, 6 Cores.', 100, 25, 'Core-i5-9400F-1200x1200.jpg'),
(9, 'CPUs', 'Intel Core i7-9700K CPU', '9th Generation, 3.60 up to 4.90 GHz, 12 MB, 8 Cores.', 150, 29, 'Core-i7-9700K-1200x1200.jpg'),
(10, 'CPUs', 'Intel Core i9-9900K CPU', '9th Generation, 3.60 up to 5.00 GHz, 16MB, 8 Cores.', 300, 20, 'Core-i9-9900K-1200x1200.jpg'),
(11, 'CPUs', 'AMD RYZEN 7 5800X CPU', 'AMD\'s fastest 8 core processor for mainstream\r\ndesktop, with 16 procesing threads.', 300, 35, 'AMD-CPU-Ryzen-7-5800X.jpg'),
(12, 'CPUs', 'AMD RYZEN 5 3600X CPU', 'AMD Ryzen™ 5 3600X, AM4, Zen 2, 6 Core, 12\r\nThread, 3.8GHz, 4.4GHz Turbo, 32MB L3, PCIe 4.0,\r\n65W.\r\n', 220, 12, 'AMD Ryzen 5 3600X.jpg'),
(13, 'CPUs', 'AMD RYZEN 9 7950X CPU', 'AMD Ryzen 9 7950X with a 16-core processor and 32 threads.', 450, 5, 'AMD-RYZEN-9-7950X.jpg'),
(14, 'RAMs', 'Kingston RAM FURY For Desktop Beast 32GB 6000MHz DDR5', '32GB 6000MHz DDR5 for desktops | RGB', 50, 100, 'Kingston RAM FURY 32gb.png'),
(15, 'RAMs', 'Kingston RAM FURY For Desktop Beast 16GB 5600MHz DDR5 ', '16GB 5600MHz DDR5 for desktops | RGB', 30, 97, 'Kingston RAM FURY For Desktop Beast 16GB 5600MHz.jpg'),
(16, 'RAMs', 'Kingston RAM FURY For Desktop Beast 8 GB 5200MHz DDR5', '8 GB 5200MHz DDR5 for desktops | RGB', 20, 50, 'Kingston RAM FURY For Desktop Beast 8 GB 5200MHz.jpg'),
(17, 'RAMs', 'Kingston Ram 32GB 5200 Mhz DDR5 SODIMM for Laptop', '32GB 5200 Mhz DDR5 SODIMM for Laptop', 40, 100, 'Kingston Ram 32GB 5200 Mhz DDR5 SODIMM for Laptop.jpg'),
(18, 'RAMs', 'Kingston Fury Ram 16GB 5600 Mhz DDR5 for Laptop', '16GB 5600 Mhz DDR5 Low 1.1V Power Draw Less Heat SODIMM for Laptop', 30, 90, 'Kingston Fury Ram 16GB 5600 laptop.jpg'),
(19, 'RAMs', 'Kingston Ram for Laptop 8GB 3200Mhz DDR4', '8GB 3200Mhz DDR4 for Laptop ', 20, 250, 'Kingston Ram for Laptop 8GB.jpg'),
(20, 'SSDs&HDDs', 'Kingston SSD A400 / 240GB ', '240 GB', 20, 20, 'Kingston SSD A400 240G.jpg'),
(21, 'SSDs&HDDs', 'Kingston SSD A400 / 480GB ', '480GB ', 35, 28, 'Kingston SSD A400 480G.jpg'),
(22, 'SSDs&HDDs', 'Kingston SSD A400 / 960GB', '960GB', 70, 30, 'Kingston SSD A400 960G.jpg'),
(23, 'SSDs&HDDs', 'Internal WD Purple 2TB Hard Drive', '2TB Hard Drive', 20, 30, 'Internal WD Purple 2TB Hard Drive.jpg'),
(24, 'SSDs&HDDs', 'Internal WD Purple 4TB Hard Drive', '4TB Hard Drive', 30, 19, 'Internal WD Purple 4TB Hard Drive.jpg'),
(25, 'SSDs&HDDs', 'Internal WD Purple 8TB Hard Drive', '8TB Hard Drive', 50, 10, 'Internal WD Purple 8TB Hard Drive.jpg'),
(26, 'MOTHERBOARDs', 'MSI PRO B650M-B MotherBoard', 'AMD RYZEN 7000 Series AM5/DDR5/PCIe 4.0/1xM.2 - mATX Gaming.', 500, 10, 'MSI-PRO-B650M-B-Motherboard.jpg'),
(27, 'MOTHERBOARDs', 'GIGABYTE B650 AORUS ELITE AX ICE MotherBoard', '(Wi-Fi 6E) AMD RYZEN 7000 Series AM5/DDR5/PCIe 4.0/3xM.2 - ATX Gaming MotherBoard.', 600, 20, 'B650-AORUS-ELITE-AX-ICE-Motherboard.jpg'),
(28, 'MOTHERBOARDs', 'ASUS PRIME H610M-D D4 MotherBoard', 'Intel 14th 13th 12th Series, LGA 1700/DDR4/PCIe 4.0/1xM.2 - mATX MotherBoard.', 400, 13, 'ASUS PRIME H610M Motherboard.jpg'),
(29, 'MOTHERBOARDs', 'GIGABYTE H610M K MotherBoard', 'Intel 14th 13th 12th Series, LGA 1700/DDR4/PCIe 4.0/1xM.2 - mATX.', 400, 8, 'GIGABYTE-H610M-K-DDR4-Motherboard.jpg'),
(30, 'MOTHERBOARDs', 'MSI MAG Z790 TOMAHAWK MotherBoard', 'MAX WIFI (Wi-Fi 7), Intel 14th 13th 12th Series, LGA 1700/DDR5/PCIe 5.0/4xM.2 - ATX Gaming.', 600, 18, 'MAG-Z790-TOMAHAWK-MAX-WIFI-DDR5-Motherboard.jpg'),
(31, 'MOTHERBOARDs', 'MSI MEG Z790 ACE MotherBoard', 'MAX Wi-Fi 7, Intel 14th 13th 12th Series, LGA 1700/DDR5/PCIe 5.0/5xM.2 - ATX Gaming', 600, 10, 'MEG-Z790-ACE-MAX-Motherboard.jpg'),
(32, 'GPUs', 'GIGABYTE AORUS GeForce RTX 4080 MASTER 16GB GDDR6X', 'GIGABYTE AORUS GeForce RTX 4080 MASTER 16GB GDDR6X.', 800, 30, 'gigabyte-aorus-master-rtx-4080-16gb-tarjeta-grafica-CPUs.jpg'),
(33, 'GPUs', 'GIGABYTE GeForce RTX 4070 SUPER AERO OC 12GB GDDR6X', 'GIGABYTE GeForce RTX 4070 SUPER AERO OC 12GB GDDR6X.', 750, 10, 'GIGABYTE GeForce RTX 4070 SUPER AERO OC 12GB GDDR6X gpu.jpg'),
(34, 'GPUs', 'GIGABYTE GeForce RTX 4070 SUPER WINDFORCE OC 12GB GDDR6X.', 'GIGABYTE GeForce RTX 4070 SUPER WINDFORCE OC 12GB GDDR6X.', 700, 19, 'GIGABYTE GeForce RTX 4070 SUPER WINDFORCE OC 12GB GDDR6X gpu.jpg'),
(35, 'GPUs', 'ASUS ROG Strix GeForce RTX 4080 SUPER White OC Edition 16GB GDDR6X.', 'ASUS ROG Strix GeForce RTX 4080 SUPER White OC Edition 16GB GDDR6X.', 900, 20, 'ASUS ROG Strix GeForce RTX 4080 SUPER White OC Edition 16GB GDDR6X gpu.jpg'),
(36, 'GPUs', 'GIGABYTE AORUS GeForce RTX 4080 SUPER MASTER 16GB GDDR6X.', 'GIGABYTE AORUS GeForce RTX 4080 SUPER MASTER 16GB GDDR6X.', 850, 20, 'GIGABYTE AORUS GeForce RTX 4080 SUPER MASTER 16GB GDDR6X gpu.jpg'),
(37, 'GPUs', 'GIGABYTE GeForce RTX 3050 EAGLE OC 6GB GDDR6', 'GIGABYTE GeForce RTX 3050 EAGLE OC 6GB GDDR6.', 550, 10, 'GIGABYTE GeForce RTX 3050 EAGLE OC 6GB GDDR6 gpu.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `orderedproducts`
--
ALTER TABLE `orderedproducts`
  ADD PRIMARY KEY (`productId`);

--
-- Indexes for table `orderstable`
--
ALTER TABLE `orderstable`
  ADD PRIMARY KEY (`OrderID`);

--
-- Indexes for table `products_description`
--
ALTER TABLE `products_description`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `orderstable`
--
ALTER TABLE `orderstable`
  MODIFY `OrderID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `products_description`
--
ALTER TABLE `products_description`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
