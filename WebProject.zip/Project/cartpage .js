

let modal=document.getElementById("modal");
let popup=document.getElementById("popupdiv");
var i;
var element={}
function openPopup(elem,index){
    element=elem;
    i=index;
popup.classList.add("openpopup");
modal.classList.add("openpopup");
}
function closePopup(){
    popup.classList.remove("openpopup");
    modal.classList.remove("openpopup");
}
function opencoupon(){
  
document.getElementById("couponpopup").classList.add("openpopup");
modal.classList.add("openpopup");
}
function closecoupon(){
    document.getElementById("couponpopup").classList.remove("openpopup");
    modal.classList.remove("openpopup");
}



function applyCoupon(){
   
        
        document.getElementById("inputdiv").innerHTML="";
        document.getElementById("inputdiv").innerText="COUPON APPLIED";
        document.getElementById("inputdiv").style.color="#ff3f6c";
        document.getElementById("inputdiv").style.padding="5px 80px";
           
    
}
var lestOfCobons=[];
var totalWithCoupons=0;
function addCoupon( cobon,total){
lestOfCoupons.push(cobon);
clacTotalPrice(total);
}
function clacTotalPrice(total){
    lestOfCobons.forEach(element => {
    if(total>0){
        total=total-element;
    }
    });
    totalWithCoupons=total;
} 
function remove(id){


}