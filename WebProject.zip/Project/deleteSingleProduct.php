<?php 
    

        
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "products_descriptionDB";
    
    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    $myId=$_GET['myinput'];
    $sql= "DELETE FROM orderedproducts WHERE productId='$myId'"; 
    $result = $conn->query($sql);

    $conn->close();    
    header("Location:cartpage.php");

?>  