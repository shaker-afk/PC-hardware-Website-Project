<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  
    <link href="IndexStyle.css" rel="stylesheet">
    <link href="SignUpstyle.css" rel="stylesheet">
    <title>Login</title>
</head>
<body>


    <form id="form1" method="post" action="SignUpHandler.php">
    <div class="wrapper">
        <div class="toggleleft">
            <h1 class="signup_Text" onclick="submitSignUpForm()">Sign Up</h1>
          <br>
          <div id="Text1">
            <br>
            <p > Already have an account?</p>
             <a onclick="GoToLoginPage()" style="text-decoration: underline; color: #DC965A;">login into account.</a>
             <br><br>
             <div  style="text-decoration: underline; color: #DC965A;" onclick="IndexCalled()">Return to Homepage</div>
           </div>
        </div>
       
        <br>
        <div class="SignUp"> 
            <div class="FirstName">
                <input type="text" name="FirstName" id="FirstName" placeholder="First Name" class="FirstName" required>
            </div>
            <br>
            <div class="LastName">
                <input type="text" name="LastName" id="LastName" placeholder="Last Name" class="LastName" required>
            </div>
            <br>
            <div class="UserEmail">
                <input type="email" name="UserEmail" id="UserEmail" placeholder="Email" class="UserEmail" required>
            </div>
            <br>
            <div class="PhoneNumber">
                <input type="number" name="PhoneNumber" id="PhoneNumber" placeholder="Phone Number" class="PhoneNumber" required>
            </div>
            <br>
            <div class="SignUpUsername">
                <input type="text" name="username" id="username" placeholder="Username" class="username" required>
            </div>   
            <br>  
            <div class="SignUpUsernamePassword">
                <input type="password" name="UserPassword" id="password" placeholder="Password" class="password" required>
            </div>
            <br>
            
            
           
        </div>
    </div>

<input type="submit" hidden id="Sbmtbtn">

</form>









<script>
    function submitSignUpForm(){
        document.getElementById("Sbmtbtn").click();
    }
    function GoToLoginPage(){
        window.location = "Login.php";
    }
    function IndexCalled(){
        window.location.href = "Index.php";
    }
    
</script>


</body>
</html>