<script>
    function errormessage() {
        window.alert("Cannot add this product to cart.\nNo more stock!");
        window.location.href = "http://localhost/Project/Products.php";
    }

    function redirectToProducts() {
        window.alert("Product added to cart successfully");
        window.location.href = "http://localhost/Project/Products.php";
    }
</script>
<?php
session_start();
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "products_descriptionDB";

$conn = new mysqli($servername, $username, $password, $dbname);

if(isset($_SESSION['username'])){

}
else{
    echo"<script>   window.location.href = 'Login.php';</script>";
}



if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$id = $_POST["productIDordered"];

$sql = "SELECT id,name, price, stock FROM products_description where id = '$id'"; //select the product from products table
$productquery = $conn->query($sql);

$sql3 = "SELECT productStock,quantity FROM orderedproducts where productId = '$id'"; //see if this product has been inserted before
$result = $conn->query($sql3);

if($result -> num_rows > 0){
    $updateProduct = $result->fetch_assoc();
    if($updateProduct["quantity"] < $updateProduct["productStock"]){
        $newQuantity = $updateProduct["quantity"] + 1;
        $sqlupdate = "UPDATE orderedproducts SET quantity = $newQuantity WHERE productId = $id";
        if ($conn->query($sqlupdate) === TRUE) 
            echo "<script>redirectToProducts();</script>";	
        else 
            echo "Error: $sqlupdate <br> $conn->error";	
    }
    else
        echo "<script>errormessage();</script>";
}else
{
    if ($productquery->num_rows > 0) {
        $row = $productquery->fetch_assoc();
        $id = $row["id"];
        $name = $row["name"];
        $price = $row["price"];
        $stock = $row["stock"];
        $sql2 = "INSERT INTO orderedproducts (productId, productName, productPrice, productStock,quantity)	VALUES ($id, '$name', $price, $stock, 1)";
        if ($conn->query($sql2) === TRUE) 
            echo "<script> redirectToProducts(); </script>";	
        else 
            echo "Error: $sql2 <br> $conn->error";	

    } else {
        echo "No products found.";
    }
}

$conn->close();

?> 