<?php 
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "userdb";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection to Users data base failed". $conn->connect_error);
}
$UserName = $_POST["username"];
$UserPass = $_POST["UserPassword"];


//Select Query
$sql = "SELECT username, UserPassword FROM userdata WHERE username = '$UserName' AND UserPassword = '$UserPass' ";
$result = $conn->query($sql);
if ($result->num_rows == 0) {
    echo "<script>alert('Wrong username or password, try again'); 
    window.location.href = 'Login.php';</script>";
}
else{
    header("Location: LoginSuccessfull.php");
    $LoggedInUserData = $result->fetch_assoc();
    $_SESSION['username'] = $LoggedInUserData['username'];
  

}
$LoggedInUserData = $result->fetch_assoc();
$_SESSION['UserID'] = $LoggedInUserData['UserID'];



$conn->close();

?>
