<!DOCTYPE html>
<html>
    <head>
        <title>Checkout</title>
    </head>
    <body>
        <?php
            // retrieve values from the form
            session_start();
            $servername = "localhost";	
            $username = "root";	
            $password = "";	
            $dbname = "checkoutdb";

           
            
            // 1- connect to DB server
            $conn = new mysqli("localhost", $username, $password, $dbname);



            if ($conn->connect_error)
            { exit("Connection failed: " . $conn->connect_error);	}

            
            $fname = $_POST["FirstName"];
            $lname = $_POST["LastName"];
            $mail = $_POST["User_Email"];
            $address = $_POST["address"];
            $address2 = $_POST["address2"];
            $myCity = $_POST["city"];
            $zip = $_POST["zip"];
            $pMethod=$_POST["payment"];
            $ccn=$_POST["credit"];
            $cch=$_POST["holder"];
            $delev=$_POST["Delivery"];
            $note=$_POST["notes"];


            
            // build sql query
            $sql = "INSERT INTO checkoutdb (firstName, lastName, Email, Address, Address2, City, zipCode, paymentMethod, creditCard, CreditHolder, dTime, Notes)
                VALUES ('$fname', '$lname', '$mail', '$address', '$address2', '$myCity', '$zip', '$pMethod', '$ccn', '$cch', '$delev', '$note')";
                
            if ($conn->query($sql) === TRUE) 
            { header("Location: OrderConfirmation.php");	exit;} 
            
            
            else { echo "Error: " . $sql . "<br>" . $conn->error;	}	    
                
            $conn->close();?> 
                    
            
        ?>

    

    </body>
</html>