<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "products_descriptionDB";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$group = $_POST["groupclicked"];

$sql = "SELECT id,name, price, image FROM products_description where groupName = '$group'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $img = $row["image"];
        $id = $row["id"];
        echo "<div class=\"items\" onclick=\"openProductDescriptionPage($id)\">";
        echo "<img class=\"product_images\" src=\"$img\" >";
        echo '<p class="product_description">' . $row['name'] . '</p>';
        echo '<p class="product_price">Price: $' . $row['price'] . '</p>';
        // echo "<button type=\"button\" class=\"btn btn-default btn-sm mybtn\" onclick=\"addtocart($id)\">";
        // echo '<span class="glyphicon glyphicon-shopping-cart"></span>';
        // echo '<b> Add to Cart </b>';
        // echo '</button> <br><br>';
        echo '</div>';
    }
} else {
    echo "No products found.";
}


$conn->close();
?>
