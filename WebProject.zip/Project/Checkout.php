<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "products_descriptiondb";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}



$myuser = $_SESSION["UserID"];

$sql = "SELECT productPrice, quantity FROM orderedproducts WHERE userId = '$myuser'";
$result = $conn->query($sql);

$total = 0;

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $total += $row["productPrice"] * $row["quantity"];
    }
    $_SESSION["UserTotal"] = $total;
} else {
    echo "No records found.";
}


        $sql = "SELECT productId, quantity FROM orderedproducts WHERE userId = '$myuser'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $productId = $row["productId"];
                $quantity = $row["quantity"];

                // Deducting stock for the ordered product
                $updateStockSql = "UPDATE products_description SET stock = stock - $quantity WHERE id = $productId";
                $conn->query($updateStockSql);
            }
        } else {
            echo "No records found.";
        }
        
    



?>


<!DOCTYPE html>
<html>
    <head>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
        <link href="IndexStyle.css" rel="stylesheet">
        <link href="CheckoutStyle.css" rel="stylesheet">
   
        <script>
            function Cred() {
                var pay = document.getElementById("payment").value;
                var info = document.getElementById("u1");
                var info2= document.getElementById("u2");

                if(pay=="Cash"){
                    info.innerHTML=""
                    info2.innerHTML=""
                }else{
                    info.innerHTML=`Credit Card Number: <input type="text" name="credit" id="credit" pattern="[0-9]{16}" required maxlength="16" minlength="16" style="width: 300px;"> `
                    info2.innerHTML=`Name on Credit Card: <input type="text" name="holder" id="holder" required style="width: 380px;">`
                }
            }
        </script>
     
    </head>
    <body>
        <!--Website Header-->
 <header>
    <!--Email-->
<a id="Top"></a>
<div class="FlexBoxTest">
    <div id="EmailPart">
        <div id="EmailLogo"> 
            <a href="mailto:Company@gmail.com">
            <svg class="HeaderLogos"  xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--!Font Awesome Free 6.5.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path fill="#f5f5f5" d="M48 64C21.5 64 0 85.5 0 112c0 15.1 7.1 29.3 19.2 38.4L236.8 313.6c11.4 8.5 27 8.5 38.4 0L492.8 150.4c12.1-9.1 19.2-23.3 19.2-38.4c0-26.5-21.5-48-48-48H48zM0 176V384c0 35.3 28.7 64 64 64H448c35.3 0 64-28.7 64-64V176L294.4 339.2c-22.8 17.1-54 17.1-76.8 0L0 176z"/></svg>
        
        </div>
    
        <div id="EmailP1">
            <p >info@company.com</p>
        </div>
    </a>
    </div>
    <div id="Promocode">
         <!--Promocode-->
   <p  >USE CODE FULL_MARK_IN_PROJECT FOR 20% OFF!</p>
    </div>
    
   <!--SocialMedia-->
    <div id="Socials">
        <div id="SocialsFlexBox">
        <a href="https://www.instagram.com/psutofficial/">
            <svg class="HeaderLogos" id="InstagramLogo"  xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><!--!Font Awesome Free 6.5.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path fill="#ffffff" d="M224.1 141c-63.6 0-114.9 51.3-114.9 114.9s51.3 114.9 114.9 114.9S339 319.5 339 255.9 287.7 141 224.1 141zm0 189.6c-41.1 0-74.7-33.5-74.7-74.7s33.5-74.7 74.7-74.7 74.7 33.5 74.7 74.7-33.6 74.7-74.7 74.7zm146.4-194.3c0 14.9-12 26.8-26.8 26.8-14.9 0-26.8-12-26.8-26.8s12-26.8 26.8-26.8 26.8 12 26.8 26.8zm76.1 27.2c-1.7-35.9-9.9-67.7-36.2-93.9-26.2-26.2-58-34.4-93.9-36.2-37-2.1-147.9-2.1-184.9 0-35.8 1.7-67.6 9.9-93.9 36.1s-34.4 58-36.2 93.9c-2.1 37-2.1 147.9 0 184.9 1.7 35.9 9.9 67.7 36.2 93.9s58 34.4 93.9 36.2c37 2.1 147.9 2.1 184.9 0 35.9-1.7 67.7-9.9 93.9-36.2 26.2-26.2 34.4-58 36.2-93.9 2.1-37 2.1-147.8 0-184.8zM398.8 388c-7.8 19.6-22.9 34.7-42.6 42.6-29.5 11.7-99.5 9-132.1 9s-102.7 2.6-132.1-9c-19.6-7.8-34.7-22.9-42.6-42.6-11.7-29.5-9-99.5-9-132.1s-2.6-102.7 9-132.1c7.8-19.6 22.9-34.7 42.6-42.6 29.5-11.7 99.5-9 132.1-9s102.7-2.6 132.1 9c19.6 7.8 34.7 22.9 42.6 42.6 11.7 29.5 9 99.5 9 132.1s2.7 102.7-9 132.1z"/></svg>
        </a>
        <a href="https://www.google.com/maps/place/Princess+Sumaya+University+for+Technology/@32.0234755,35.8735991,17z/data=!3m1!4b1!4m6!3m5!1s0x151c9fa16e6250e1:0x36e46cbcb207a3fa!8m2!3d32.023471!4d35.876174!16zL20vMDY5eGI1?entry=ttu">
           <svg class="HeaderLogos" id="LocationLogo"  xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><!--!Font Awesome Free 6.5.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path fill="#ffffff" d="M215.7 499.2C267 435 384 279.4 384 192C384 86 298 0 192 0S0 86 0 192c0 87.4 117 243 168.3 307.2c12.3 15.3 35.1 15.3 47.4 0zM192 128a64 64 0 1 1 0 128 64 64 0 1 1 0-128z"/></svg>
        </a>
        <a href="https://www.facebook.com/PSUTOFFICIAL">
           <svg class="HeaderLogos" id="FacebookLogo" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--!Font Awesome Free 6.5.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path fill="#ffffff" d="M512 256C512 114.6 397.4 0 256 0S0 114.6 0 256C0 376 82.7 476.8 194.2 504.5V334.2H141.4V256h52.8V222.3c0-87.1 39.4-127.5 125-127.5c16.2 0 44.2 3.2 55.7 6.4V172c-6-.6-16.5-1-29.6-1c-42 0-58.2 15.9-58.2 57.2V256h83.6l-14.4 78.2H287V510.1C413.8 494.8 512 386.9 512 256h0z"/></svg>
        </a>
        </div>
    </div>

  
</div>

 
</header>



    <!--NavBarflexBox-->
<div id="Navigation_bar">
    <!--Company Logo-->
    
    <h3 id="CompanyLogo" onclick="IndexCalled()">CSsystems</h3>
  

    <!--CPU-->
 
    <div class="NavBar_CPU" onclick="submitform('CPUs')">
       
    <svg   xmlns="http://www.w3.org/2000/svg" width="55" height="50" viewBox="0 0 24 24" style="fill: rgba(0, 0, 0, 1);transform: ;msFilter:;"><path d="M19 7a2 2 0 0 0-2-2h-1V2h-2v3h-4V2H8v3H7a2 2 0 0 0-2 2v1H2v2h3v4H2v2h3v1a2 2 0 0 0 2 2h1v3h2v-3h4v3h2v-3h1a2 2 0 0 0 2-2v-1h3v-2h-3v-4h3V8h-3V7zm-4 8H9V9h6v6z"></path></svg>

    <h4>CPU</h4>

    </div>
   
    <!--RAM-->
    <div class="NavBar_RAM" onclick="submitform('RAMs')">
      
        <svg xmlns="http://www.w3.org/2000/svg"  width="55" height="50"  shape-rendering="geometricPrecision" text-rendering="geometricPrecision" image-rendering="optimizeQuality" fill-rule="evenodd" clip-rule="evenodd" viewBox="0 0 512 375.4"><path fill-rule="nonzero" d="M25.13 39.95h34.22V0H85.2v39.95h47.65V0h25.84v39.95h47.64V0h25.84v39.95h47.65V0h25.84v39.95h47.65V0h25.84v39.95h47.65V0h25.84v39.95h34.23c6.88 0 13.15 2.82 17.71 7.37l.05.05c4.54 4.55 7.37 10.82 7.37 17.71v247.73c0 6.88-2.83 13.15-7.37 17.71l-.05.05c-4.56 4.54-10.83 7.37-17.71 7.37h-34.23v37.46H426.8v-37.46h-47.65v37.46h-25.84v-37.46h-47.65v37.46h-25.84v-37.46h-47.65v37.46h-25.84v-37.46h-47.64v37.46h-25.84v-37.46H85.2v37.46H59.35v-37.46H25.13c-6.89 0-13.15-2.83-17.71-7.37l-.05-.05C2.83 325.96 0 319.69 0 312.81V65.08c0-6.89 2.83-13.16 7.37-17.71l.05-.05c4.56-4.55 10.82-7.37 17.71-7.37zm154.83 200.1h-35.98l-13.41-30.42h-8.56v30.42H90.83V137.84h51.52c23.44 0 35.16 11.94 35.16 35.81 0 16.36-5.07 27.15-15.21 32.38l17.66 34.02zm-57.95-77.57v23.5h9.05c3.93 0 6.79-.41 8.59-1.23 1.8-.82 2.7-2.7 2.7-5.64v-9.76c0-2.95-.91-4.83-2.7-5.64-1.8-.82-4.67-1.23-8.59-1.23h-9.05zm98.67 77.57h-34.5l26.49-102.21h50.53l26.49 102.21h-34.5l-3.76-16.19h-26.99l-3.76 16.19zm13.29-70.81-3.64 28.62h15.04l-3.48-28.62h-7.92zm96.93 70.81h-34.18l6.21-102.21h42.69l12.76 52h1.14l12.75-52h42.68l6.22 102.21h-34.18l-1.96-49.55h-1.15l-12.43 49.55h-25.01l-12.59-49.55h-.99l-1.96 49.55zM486.16 65.79H25.84V312.1h460.32V65.79z"/></svg>
        <h4>RAM</h4>
    
    </div>

    <!--SSD/HDD-->
    <div class="NavBar_SSD_HDD" onclick="submitform('SSDs&HDDs')">
        
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" style="fill: rgba(0, 0, 0, 1);transform: ;msFilter:;"><path d="m21.983 13.821-1.851-10.18A1.998 1.998 0 0 0 18.165 2H5.835a2 2 0 0 0-1.968 1.643l-1.85 10.178.019.003c-.012.06-.036.114-.036.176v5c0 1.103.897 2 2 2h16c1.103 0 2-.897 2-2v-5c0-.063-.024-.116-.035-.176l.018-.003zM5.835 4h12.331l1.637 9H4.198l1.637-9zM4 19v-4h16l.002 4H4z"></path><path d="M17 16h2v2h-2zm-3 0h2v2h-2z"></path></svg>
        <h4>SSD/HDD</h4>
    
    </div>

    <!--Motherboards-->
    <div class="NavBar_MotherBoards" onclick="submitform('MOTHERBOARDs')">
        
        <img src="motherboard.png">
        <h4>Motherboard</h4>
        
    </div>

        <!--Desktops-->
        <div class="NavBar_Desktop" onclick="submitform('Desktops')">
           
            <img src="DesktopIcon.png" alt="--Desktops--">
            <h4>Desktops</h4>
        
        </div>

        <!--gpu-->
        <div class="NavBar_GPU" onclick="submitform('GPUs')">
            <img src="GPUicon.png" alt="--GPU-">
            <h4>GPU</h4>
        </div>

        <!--Laptop-->
        <div class="NavBar_Laptop"  onclick="submitform('Laptops')">
           
            <img src="LaptopIcon.png" alt="--Laptop--">
            <h4>Laptop</h4>
      
        </div>

        <!--Login-->
        <div class="NavBar_Login"  onclick="return GoToLogin()">
            <img src="Login-Logo.png" alt="--Login--">
        </div>

        <!--Cart-->
        <div class="NavBar_Cart"  onclick="return GoToCart()">
            <img src="shopping-cart.png" alt="--Cart--">
            <h4>Cart</h4> <!--java script will add number of items to 0-->
        </div>
        
        
    </div>
    
<form method="post" action="Products.php" class="hide">
    <input type="text" class="hide" id="groupclickedinput" name="groupclicked">
    <input type="submit" id="submitselectedgroup" class="hide">
</form>

       


</div>

 

        <div id="RightBoxTotal">
            <h1 style="font-size: 60px; margin-left: 10px;">Total: <br><span style="font-size: 30px;font-weight: bold;"><?php echo $total; ?></span></h2></h1>
            
        </div>

        <div class="c2">Checkout</div>
        <div>
            <form method="post" action="checkout_handler.php" >
            <div class="c1">
            
                <div class="g">
                    <img src="user.png" style="width: 50px; height: 50px;">
                    Contact Information: <br></div>
                <div>  
                    <input type="text" id="FirstName" name="FirstName" placeholder="First Name" required pattern="[A-Za-z]+"> 
                    <input type="text" id="LastName" name="LastName" placeholder="Last Name" required pattern="[A-Za-z]+">
                    <br>
                    <input type="email" id="email" name="User_Email"  placeholder="Email, ex.Myemail@gmail.com" required>
                   
                    <br>
                    <label>Address: </label><br>
                   
                    <div id="addresss">
                    <input type="text" name="address"  placeholder="Address" required>
                    <br>
                    <input type="text" name="address2"  placeholder="Apartment, building , ext. (Optional)">
                    </div>
                    <label>City:</label>
                    <select name="city" class="city" required place style="display: inline;">
                      
                        <option  class="city" value="Amman">Amman</option>
                        <option  class="city" value="Al-Karak">Al-Karak</option>
                        <option   class="city" value="Irbid">Irbid</option>
                        <option  class="city" value="Jarash">Jarash</option>
                        </select>
                        <label>Zip Code:</label>
                        <input type="text" name="zip" id="zip" pattern="\d{5}" required minlength="5" maxlength="5" placeholder="11191">
                </div>
                <hr id="Horizontal_Rule" style="border-color: #DC965A;">
            <div class="g" >Payment Information:-</div>
                <div>
                    <label for="payment">Choose a Payment Method:</label>

                    <select name="payment" id="payment"  class="city"  class="city"  required onchange="Cred()">
                    <option value="Cash"  class="city" >Cash</option>
                    <option value="Credit"  class="city" >Credit Card</option>
                    </select>
                </div>
                <div  id="u1"> </div>
                <div id="u2"></div>
              
        
        
            <div class="g" >Delivery Information:-</div>
            <div>
                <label for="Delivery">Choose Preferred Delivery Time:</label>

                    <select name="Delivery" id="Delivery" class="city"  required style="width: 190px;">
                    <option class="city" value="1">1 AM - 10 AM</option>
                    <option class="city" value="2">11 AM - 2 PM</option>
                    <option class="city" value="2">3 PM - 6 PM</option>
                    <option class="city" value="2">6 PM - 11 PM</option>
                    </select>
            </div>
            <div>Do you have any Additional Notes for Shop / Delivery Driver?
                <textarea rows="2" cols="23" name="notes" id="notes" style="color: black;"></textarea>
            </div>
            
            <div><input type="checkbox" name="agree" id="agree" required>   I Agree to the Terms of Service</div>
            <div><button type="submit" name="submit" id="Confirmbtn" onsubmit="GoToConfirmation()">Confirm Payment</button>
            </div>
        </div>
        </form>
    </div>
    <br><br><br><br><br><br><br><br>
    <a href="#Top" id="LinkToTop">
    <div id="bookmark">
        <h4>Back to top</h4>
    </div>
<footer>
<hr>
    
    </a>
    <div id="FooterInfo">
        <h1 id="AboutUS_Text">
            About US
        </h1>
        <p id="AboutUS_Paragraph">
            Welcome to ######, your best destination for all your computer hardware needs.
            Here at ###### we understand that every customer wants top quality hardware at 
            competitive prices.

            At ######, we create a personalized experience with our customers to ensure their needs are
            satisfied. That's why we offer a carefully curated selection of CPU's, RAM, storage devices, motherboards, 
            Desktops, computer GPU's and Laptops.
        </p>
    </div>
    <div id="FooterInfo2">
        <h1>More about us:</h1>
        <p> 32-Wasfi Al-Tal street (Gardenz), Next to Dawacom pharmacy<br>Amman-jordan
        <br><br>
        <img src="cell-phone.png">
        068-312-345 / 069-351-242 / 066-924-901
        <br>
        <img src="whatsapp.png">
        079-213-4628
        <br>
        <img src="mail.png"> companySales@gmail.com
        <br> <br>
       <b><u> Working Hours:</b></u>
       <br>
       Sunday-Thursday: 8 AM - 10 PM <br>
       Friday: 2 PM - 6 PM  <br>
       Saturday: 11 AM - 7 PM  <br>
        </p>
    </div>
</footer>
<div id="Credit">
    <p>Web development by: Omar Tardi (20220598) - Malik Mahmoud (20220659) - Mohammed Amr (20220887) - Mohammad Al Qadi (20220377)
        </p>

</div>

  

<script>

    function submitform(nameofgroup){
        groupclicked = nameofgroup;
        document.getElementById("groupclickedinput").value = groupclicked;
        document.getElementById("submitselectedgroup").click();
    }
    function IndexCalled(){
        window.location.href = "Index.php";

    }
    function GoToProducts(){
        window.location = "Products.php";
        const page = window.open('Products.php');
        page.document.get
    }
    function GoToCart(){
        window.location.href = "cartpage.php";

    }
    function GoToLogin(){
        window.location.href = "Login.php";
    }
    function LoginInmessage(){
        window.location = "Login.php";
        alert("Log in first to proceed");
    }
    function GoToConfirmation(){
            
            window.location.href = "OrderConfirmation.php";
        }


</script>
     
    </body>
</html>