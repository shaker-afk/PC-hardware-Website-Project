<?php 

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "userdb";


$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection to Users data base failed". $conn->connect_error);
}

$FirstName = $_POST["FirstName"];
$LastName = $_POST["LastName"];
$Email = $_POST["UserEmail"];
$PhoneNumber = $_POST["PhoneNumber"];
$UserName = $_POST["username"];
$UserPass = $_POST["UserPassword"];

//Check if user already exists based on email;
$sql = "SELECT UserEmail FROM userdata WHERE UserEmail = '$Email'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    echo "<script>alert('This email is already in use');</script>"; 
    echo "<script>window.location.href = 'CreateAccount.php';</script>";
}
else{//Insert Query
     $sql = "INSERT INTO userdata (FirstName,LastName,UserEmail,PhoneNumber,username,UserPassword) VALUES('$FirstName','$LastName','$Email','$PhoneNumber','$UserName','$UserPass')";
     if($conn->query($sql) === TRUE) {
         header("Location: SignUPSuccessfull.php");
     }
     else {
         echo "Error: " . $sql . "<br>" . $conn->error;
     }
    }


$conn->close();

?>
