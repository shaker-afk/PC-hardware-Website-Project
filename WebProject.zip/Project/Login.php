<html>
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  
    <link href="IndexStyle.css" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="Login2.css" rel="stylesheet">
    <title>Login</title>
</head>
<body>
    
    <form id="form2" method="post" action="LoginPageHandler.php">
    <div class="wrapper">
        <div class="toggleleft">
            <h1 class="signin_Text" onclick="submitSignInForm()">Sign In</h1>
            <br><br><br>
            <div id="Text2">
                <p>Don't have an account ? </p>
               <a onclick="GoToSignUPpage()" style="text-decoration: underline; color: #DC965A;"> Create a new account.</a>
               <br><br>
               <div  style="text-decoration: underline; color: #DC965A;" onclick="IndexCalled()">Return to Homepage</div>
            </div>
        </div>

        <br>
        <br>
        <div class="SignIn"> 
            <div class="SignInUsername">
                <input type="text" name="username" id="username" placeholder="Username" class="username" required>
            </div>   
            <br>  
            <div class="SignInUsernamePassword">
                <input type="password" name="UserPassword" id="password" placeholder="Password" class="password" required>
            </div>
            <br>
            <input type="submit" value="Sign In" id="subbtn" hidden>
            <br>
           
        </div>
    </div>


</form>

<script>
    function submitSignInForm(){
        document.getElementById("subbtn").click();
    }
   
    function GoToSignUPpage(){
        window.location = "CreateAccount.php";
    }
    function IndexCalled(){
        window.location.href = "Index.php";
    }

<?php 

session_start();
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "products_descriptionDB";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);


// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


    $sql = "DELETE FROM orderedproducts";
    $result = $conn->query($sql);
   
$conn->close();


?>
</script>
</body>
</html>