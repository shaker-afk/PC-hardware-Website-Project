<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <title>title</title>
</head>
<body style="background-color: #DC965A; text-align: center;">
    <h1 style="font-size: 7em;">Account Registered successfully</h1>
    <img src="checked.png" style="height: 300px;width: 300px; display: inline-block;"> <br><br><br>
    <h1 style="text-align: center; color: #242325; display: inline; border-style: solid; font-size: 5em;background-color: rgb(74, 223, 74); border-radius: 30px; padding: 20px;" onclick="GoToHomepage()">Proceed</h1>

    <script>
     function GoToHomepage(){

        window.location ="Index.php";
     }
    </script>
</body>
</html>